<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Resizable Input</title>
<style>
/* CSS for resizable input */
.resizable-input {
    position: relative;
    width: 200px; /* Initial width */
    min-height: 40px; /* Initial height */
    resize: vertical;
    overflow: auto;
}

.resizable-input input {
    width: 100%;
    height: 100%;
    border: none;
    outline: none;
    box-sizing: border-box;
    padding: 5px;
    font-size: 16px;
}

.resizable-input .resize-handle {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 20px;
    height: 20px;
    cursor: ns-resize;
    background-color: #ccc;
}
</style>
</head>
<body>

<!-- Resizable input -->
<div class="resizable-input">
    <input type="text" placeholder="Drag to resize">
    <div class="resize-handle"></div>
</div>

<script>
// JavaScript for resizing functionality
const resizeHandle = document.querySelector('.resize-handle');
const input = document.querySelector('.resizable-input');

let isResizing = false;
let lastY;

resizeHandle.addEventListener('mousedown', (e) => {
    isResizing = true;
    lastY = e.clientY;

    document.addEventListener('mousemove', resize);
    document.addEventListener('mouseup', stopResize);
});

function resize(e) {
    if (isResizing) {
        const delta = e.clientY - lastY;
        input.style.height = (input.offsetHeight + delta) + 'px';
        lastY = e.clientY;
    }
}

function stopResize() {
    isResizing = false;
    document.removeEventListener('mousemove', resize);
    document.removeEventListener('mouseup', stopResize);
}
</script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\PROJECTS\LARAVEL\shyamShop-Admin\resources\views/seller/dashboard/product/test.blade.php ENDPATH**/ ?>