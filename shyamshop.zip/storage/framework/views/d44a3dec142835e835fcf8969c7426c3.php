<?php $__env->startSection('title','Edit-Product'); ?>
<?php echo $__env->make('components.seller-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .ql-editor{
        height:220px !important;
	}
	#imageContainer {
  display: flex;
  flex-wrap: wrap;
}

#imageContainer img {
  max-width: 120px;
  margin: 10px;
}

</style>


		<!--end header -->
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
					<div class="ps-3">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb mb-0 p-0">
								<li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
								</li>
								<li class="breadcrumb-item active" aria-current="page">Update Product</li>
							</ol>
						</nav>
					</div>
					<div class="ms-auto">
						<div class="btn-group">
							<a href="<?php echo e(route('seller.viewProduct')); ?>">
								<button type="button" class="btn-sm btn btn-primary">View Products</button>
							</a>
							
							
						</div>
					</div>
				</div>
				<!--end breadcrumb-->
			  
				<form action="" id="formSubmit">

					<input type="hidden" id="url" value="/seller/update-product">
					<input type="hidden" id="dataType" value="POST">

					<div class="card">
						<div class="card-body p-4">
							<h5 class="card-title"> Product Edit Form</h5>
							<hr/>
							 <div class="form-body mt-4">
							  <div class="row">
								 <div class="col-lg-8">
								 <div class="border border-3 p-4 rounded">
								  <div class="mb-3">
									  <label for="inputProductTitle" class="form-label">Product Title</label>
									  <input type="text" value="<?php echo e($product->title); ?>" class="form-control" id="inputProductTitle" placeholder="Enter product title" name="title" required>
									</div>
									<input type="hidden" name="product_id" value="<?php echo e($product->productId); ?>">
							  
									<div class="mb-3">
									  <label for="">Description</label>
									<div >
										<textarea id="mytextarea"  value="" name="mytextarea" placeholder="Type product description" required><?php echo $product->description; ?></textarea>
									</div>
								  </div>
									
									<label for="" >Choose Product images  <span class="text text-primary text-sm">( Select up to 4 Images )</span> </label>
									<div class="mb-3 border border-3  rounded p-4" >
										<input type="file" id="imageInput" multiple accept="image/*" name="image[]" >
									</div>
									<?php echo csrf_field(); ?>
									<div id="imageContainer">
										<?php
											$image = json_decode($product->images);
											?>
										<?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
										<img src="/products/<?php echo e($value); ?>" alt="image" style="border-radius: 10px;">
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								  </div>
								 </div>
								 <div class="col-lg-4">
								  <div class="border border-3 p-4 rounded">
									<div class="row g-3">
									  
										<div class="col-md-6">
										  <label for="inputCostPerPrice" class="form-label">Price</label>
										  <input type="number" class="form-control" id="inputCostPerPrice" placeholder="00.00" name="price" value="<?php echo e($product->price); ?>" required>
										</div>
										<div class="col-md-6">
										  <label for="inputStarPoints" class="form-label">Quantity</label>
										  <input type="number" class="form-control" id="inputStarPoints" placeholder="Quantity of products in stock " name="quantity" value="<?php echo e($product->quantity); ?>" required>
										</div>
										<div class="col-12">
										  <label for="inputProductType" class="form-label">Product Type</label>
										  <select class="form-select" id="inputProductType" required name="category">
											<option value="">Select Product type</option>
											  <?php for($i=0; $i < count($sellerCategory); $i++): ?>
											  <option value="<?php echo e($sellerCategory[$i]['categoryId']); ?>" <?php if($sellerCategory[$i]['categoryId']==$product->product_category_id): ?>selected
                                                  
                                              <?php endif; ?>><?php echo e($sellerCategory[$i]['categoryName']); ?></option>
											  <?php endfor; ?>
											</select>
										</div>
										
										<div class="col-12">
											<div class="d-grid mt-3">
											   <button type="submit" class="btn btn-primary" id="submitBtn">Update Product</button>
											   <button class="btn btn-primary" type="button" disabled
											   id="loadingBtn" style="display:none ; width:100% ;"> <span
												   class="spinner-border spinner-border-sm" role="status"
												   aria-hidden="true"></span>
											   <span class="visually-hidden" >Loading...</span>
										   </button>
											</div>
										</div>
									</div> 
								</div>
								</div>
							 </div><!--end row-->
						  </div>
						</div>
					</div>
				</form>


			</div>
		</div>
		<!--end page wrapper -->
		<!--start overlay-->
		<div class="overlay toggle-icon"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
        <?php echo $__env->make('components.seller-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- <script src="assets/js/bootstrap.bundle.min.js"></script> -->
	<!--plugins-->
	<script src="assets/js/jquery.min.js"></script>
	<script src="<?php echo e(url('assets/plugins/simplebar/js/simplebar.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/metismenu/js/metisMenu.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/Drag-And-Drop/dist/imageuploadify.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/js/editor.js')); ?>"></script>
	
	<script>
		 tinymce.init({
  selector: 'textarea#mytextarea',
  api_key: '2o9r5iwikkhmjkctjhysshr3mq6l03v03q5siuzq63ppwf4n',
});
		$(document).ready(function () {
			$('#image-uploadify').imageuploadify();
		});
	</script>
	<!--app JS-->
	<script src="<?php echo e(url('assets/js/app.js')); ?>"></script>
<script>
	const imageInput = document.getElementById('imageInput');
const imageContainer = document.getElementById('imageContainer');

imageInput.addEventListener('change', function() {
  imageContainer.innerHTML = ''; // Clear previous images

  const files = this.files;
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    if (!file.type.startsWith('image/')) continue; // Skip non-image files

    const reader = new FileReader();
    reader.onload = function() {
      const img = document.createElement('img');
      img.src = reader.result;
      imageContainer.appendChild(img);
    }
    reader.readAsDataURL(file);
  }
});
</script><?php /**PATH C:\xampp\htdocs\PROJECTS\LARAVEL\shyamShop-Admin\resources\views/seller/dashboard/product/editProduct.blade.php ENDPATH**/ ?>